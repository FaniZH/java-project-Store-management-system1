
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class SalesPerson extends storeMenu {
    String jdbcUrl = "jdbc:mysql://localhost:3306/product?zeroDateTimeBehavior=CONVERT_TO_NULL";
    String username = "root";
    String password = "conectSQL50";
    
    
    PreparedStatement ps;
    private String usernameSalesPerson;
    private String passwordSalesPerson;
    
    public SalesPerson(String usernameSalesPerson, String passwordSalesPerson) {
        this.usernameSalesPerson = usernameSalesPerson;
        this.passwordSalesPerson = passwordSalesPerson;
    }

    SalesPerson() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public void setUsernameSalesPerson(String usernameSalesPerson) {
        this.usernameSalesPerson = usernameSalesPerson;
    }
    public void setPasswordSalesPerson(String passwordSalesPerson) {
        this.passwordSalesPerson = passwordSalesPerson;
    }
        
    public String getUsernameSalesPerson() {
        return this.usernameSalesPerson;
    }
    public String getPasswordSalesPerson() {
        return this.passwordSalesPerson;
    }
    
    public void login(String emlpUsername, String emlpPassword) {
        try {
            con = DriverManager.getConnection(jdbcUrl, username, password);
            st = con.createStatement();
            ps = con.prepareStatement("SELECT * FROM employee_storetbl WHERE username=? AND password=?");
            ps.setString(6, emlpUsername);
            ps.setString(7, emlpPassword);
            
            rs = ps.executeQuery();
            
            if (rs.next()) {
                    JOptionPane.showMessageDialog(null, "Login successful!");
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password.");
                }

                con.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(SalesPerson.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void getUserInfo(){
        try {
            storeMenu storeMn = new storeMenu();
            storeMenu.Employee empl = storeMn.new Employee();
            usernameSalesPerson = empl.getUsername();
            passwordSalesPerson = empl.getPassword();
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(SalesPerson.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    public class orderSalesPerson extends Stock {
        
        
        public void updateOrderSale(int id, String name, String supplier, String stockDate, double amount, String invoice) {
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");

                String query = "UPDATE stocktbl SET stock_name=?, stock_supplier=?, stock_stockDate=?, stock_amount=?, stock_invoice=? WHERE stocktbl";
                ps = con.prepareStatement(query);
                ps.setInt(0, id);
                ps.setString(1, name);
                ps.setString(2, supplier);
                ps.setString(3, stockDate);
                ps.setDouble(4, amount);
                ps.setString(4, invoice);
                
                DefaultTableModel model = new DefaultTableModel();
                String row[] = {String.valueOf(id), name, supplier, stockDate, String.valueOf(amount), invoice};
                model.addRow(row);
                
                ps.executeUpdate();
            } catch (SQLException e) {
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(SalesPerson.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        public void cancelOrderSale(int id) {
            try {
                String query = "UPDATE stocktbl SET stock_amount = 0 WHERE stock_Id = ?";
                ps = con.prepareStatement(query);
                ps.setInt(0, id);
                
                ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        
        }
        
        public void searchOrderSale(String searchOrder) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bestbrightnessdb?zeroDateTimeBehavior=CONVERT_TO_NULL");
                st = con.createStatement();

                String query = "SELECT * FROM stocktbl WHERE stock_name LIKE '%" + searchOrder + "%'";
                rs = st.executeQuery(query);

                DefaultTableModel model = new DefaultTableModel();
                
                ResultSetMetaData mData = rs.getMetaData();
                int columnCount = mData.getColumnCount();
                for (int i = 1; i <= columnCount; i++) {
                    model.addColumn(mData.getColumnName(i));
                }

                while (rs.next()) {
                    Object[] row = new Object[columnCount];
                    for (int i = 1; i <= columnCount; i++) {
                        row[i-1] = rs.getObject(i);
                    }
                    model.addRow(row);
                }

                rs.close();
                st.close();
                con.close();
            } catch (SQLException ex) {
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(SalesPerson.class.getName()).log(Level.SEVERE, null, ex);
            }
            prod.notifystoremanWareHouse();
        
        }
    }
    
    public class productSalesPerson extends WareHouse {
        WareHouse wh = new WareHouse();
        WareHouse.Product prod = wh.new Product();
        
        
        public void searchProductSale(String searchProduct) throws ClassNotFoundException {
            prod.searchProductWareHouse(searchProduct);
        }
        
        public void soledProductSale(int id) {
            try{
                String query = "UPDATE warehouse_producttbl SET is_sold = ? WHERE product_id = ?";
                ps = con.prepareStatement(query);
                ps.setBoolean(5, true); 
                ps.setInt(0, id);
                ps.executeUpdate();
               
            } catch (SQLException e) {
            }
        }
        
        public ArrayList<String> highSellingProductSale(int minSalesCount) {
            ArrayList<String> highSellingProducts = new ArrayList<>();

            try{
                
                String query = "SELECT nameWareHouse_Product FROM warehouse_producttbl WHERE unitsWareHouse_Product >= 50";
                ps = con.prepareStatement(query);
                ps.setInt(1, minSalesCount);
                rs = ps.executeQuery();

                while (rs.next()) {
                    String productName = rs.getString("nameWareHouse_Product");
                    highSellingProducts.add(productName);
                }
            } catch (SQLException e) {
            }
            JOptionPane.showMessageDialog(null, "High selling product is" + highSellingProducts);
            return highSellingProducts;
        }
        
        public ArrayList<String> lowSellingProductSale(int maxSalesCount) {
            ArrayList<String> lowSellingProducts = new ArrayList<>();

            try{
                
                String query = "SELECT nameWareHouse_Product FROM warehouse_producttbl WHERE unitsWareHouse_Product <= 50";
                ps = con.prepareStatement(query);
                ps.setInt(1, maxSalesCount);
                rs = ps.executeQuery();

                while (rs.next()) {
                    String productName = rs.getString("nameWareHouse_Product");
                    lowSellingProducts.add(productName);
                }
            } catch (SQLException e) {
            }
            JOptionPane.showMessageDialog(null, "Low selling product is" + lowSellingProducts);
            return lowSellingProducts;
        }
    
        public void damagedProductSale(int id) {
            try {
                String query = "UPDATE warehouse_producttbl SET isdamaged = ? WHERE idWareHouse_Product = ?";
                ps = con.prepareStatement(query);
                ps.setBoolean(6, true); 
                ps.setInt(1, id);
                ps.executeUpdate();
                
            } catch (SQLException e) {
            }
        }
    }
    
    public class discountSales {
    
    }
    
    public class reportSales {
    
    }
    
    public class orderSales {
    
    }
    
}
